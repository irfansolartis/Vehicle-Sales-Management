package project;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Servlet implementation class sqlChecksServlet
 */
public class sqlChecksServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String url = "jdbc:mysql://localhost:3306/";
        String dbName = "vehicle_sales_db";
        String driver = "com.mysql.cj.jdbc.Driver";
        String userName = "root";
        String password = "password";

        try {
        	Class.forName(driver);
            Connection conn = DriverManager.getConnection(url, userName, password);
            Statement stmt = conn.createStatement();

            // Create database if not exists
            String createDatabaseQuery = "CREATE DATABASE IF NOT EXISTS " + dbName;
            stmt.executeUpdate(createDatabaseQuery);

            // Switch to the created or existing database
            String useDatabaseQuery = "USE " + dbName;
            stmt.executeUpdate(useDatabaseQuery);

            // Create tables if not exist
            String createVehicleTableQuery = "CREATE TABLE IF NOT EXISTS vehicle ("
                    + "vehicle_id INT AUTO_INCREMENT PRIMARY KEY,"
                    + "make VARCHAR(255) NOT NULL,"
                    + "model VARCHAR(255) NOT NULL,"
                    + "year INT NOT NULL,"
                    + "price DECIMAL(10,2) NOT NULL,"
                    + "owner VARCHAR(255),"
                    + "engine_number VARCHAR(255),"
                    + "chassis_number VARCHAR(255),"
                    + "insurance_coverage_status VARCHAR(255)"
                    + ")";
            stmt.executeUpdate(createVehicleTableQuery);

            String createTransactionTableQuery = "CREATE TABLE IF NOT EXISTS transaction ("
                    + "transaction_id INT AUTO_INCREMENT PRIMARY KEY,"
                    + "amount DECIMAL(10,2) NOT NULL,"
                    + "transaction_date DATE NOT NULL,"
                    + "profit DECIMAL(10,2),"
                    + "vehicle_id INT,"
                    + "FOREIGN KEY (vehicle_id) REFERENCES vehicle(vehicle_id)"
                    + ")";
            stmt.executeUpdate(createTransactionTableQuery);

            String createUsersTableQuery = "CREATE TABLE IF NOT EXISTS users ("
                    + "user_id INT AUTO_INCREMENT PRIMARY KEY,"
                    + "name VARCHAR(255) NOT NULL,"
                    + "user_name VARCHAR(255) UNIQUE NOT NULL,"
                    + "password VARCHAR(255) NOT NULL,"
                    + "role VARCHAR(50) NOT NULL"
                    + ")";
            stmt.executeUpdate(createUsersTableQuery);
            
            String query = "INSERT IGNORE INTO users (name, user_name, password, role) VALUES ('Admin', 'admin', 'admin', 'admin')";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.executeUpdate(query);

            String createAccessoriesTableQuery = "CREATE TABLE IF NOT EXISTS accessories ("
                    + "accessories_id INT AUTO_INCREMENT PRIMARY KEY,"
                    + "accessories VARCHAR(255) NOT NULL,"
                    + "vehicle_id INT,"
                    + "FOREIGN KEY (vehicle_id) REFERENCES vehicle(vehicle_id)"
                    + ")";
            stmt.executeUpdate(createAccessoriesTableQuery);
            
            String createScoreTableQuery = "CREATE TABLE IF NOT EXISTS score ("
                    + "score_id INT AUTO_INCREMENT PRIMARY KEY,"
                    + "vehicle_score INT NOT NULL,"
                    + "insurance_coverage_status VARCHAR(255),"
                    + "vehicle_id INT NOT NULL,"
                    + "FOREIGN KEY (vehicle_id) REFERENCES vehicle(vehicle_id)"
                    + ")";
            stmt.executeUpdate(createScoreTableQuery);

            // Forward the request to loginServlet.jsp
            request.getRequestDispatcher("loginServlet").forward(request, response);
        

            stmt.close();
            conn.close();
        } catch (ClassNotFoundException | SQLException e) {
            out.println("<html><body><b>Error: " + e.getMessage() + "</b></body></html>");
        }
    }
}
