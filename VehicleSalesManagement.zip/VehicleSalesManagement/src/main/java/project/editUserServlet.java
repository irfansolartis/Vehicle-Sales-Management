package project;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * Servlet implementation class editUserServlet
 */
public class editUserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String url = "jdbc:mysql://localhost:3306/vehicle_sales_db";
        String userName = "root";
        String password = "password";

        try {
            Connection conn = DriverManager.getConnection(url, userName, password);

            String userId = request.getParameter("userId");
            String newName = request.getParameter("newName");
            String newUsername = request.getParameter("newUsername");
            String newPassword = request.getParameter("newPassword");
            String newRole = request.getParameter("newRole");

            String updateUserQuery = "UPDATE users SET name=?, user_name=?, password=?, role=? WHERE user_id=?";
            PreparedStatement pstmt = conn.prepareStatement(updateUserQuery);
            pstmt.setString(1, newName);
            pstmt.setString(2, newUsername);
            pstmt.setString(3, newPassword);
            pstmt.setString(4, newRole);
            pstmt.setString(5, userId);

            int rowsUpdated = pstmt.executeUpdate();
            if (rowsUpdated > 0) {
            	request.setAttribute("successMessage", "User edited successfully!");
                request.getRequestDispatcher("edit_user.jsp").include(request, response);
            } else {
            	request.setAttribute("failureMessage", "Failed to edit user!");
            	request.getRequestDispatcher("edit_user.jsp").include(request, response);
            }

            pstmt.close();
            conn.close();
        } catch (SQLException e) {
            out.println("<html><body><b>Error: " + e.getMessage() + "</b></body></html>");
        }
    }

}
