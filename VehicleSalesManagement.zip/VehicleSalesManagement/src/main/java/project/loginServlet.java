package project;

import java.io.*;
import java.sql.*;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Servlet implementation class loginServlet
 */
public class loginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String url = "jdbc:mysql://localhost:3306/vehicle_sales_db";
        String dbName = "vehicle_sales_db";
        String driver = "com.mysql.cj.jdbc.Driver";
        String userName = "root";
        String password = "password";

        String username = request.getParameter("username");
        String pass = request.getParameter("password");

        try {
            Class.forName(driver);
            Connection conn = DriverManager.getConnection(url, userName, password);
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM users WHERE user_name='" + username + "' AND password='" + pass + "'");

            if (rs.next()) {
                String role = rs.getString("role");
                if (role.equals("sales")) {
                    request.getRequestDispatcher("sales.jsp").forward(request, response);
                } else if (role.equals("manager")) {
                    request.getRequestDispatcher("manager.jsp").forward(request, response);
                } else if (role.equals("admin")) {
                    request.getRequestDispatcher("admin.jsp").forward(request, response);
                }
            } else {
                request.setAttribute("failureMessage", "Incorrect username/password!");
                request.getRequestDispatcher("login.jsp").include(request, response);
            }

            rs.close();
            stmt.close();
            conn.close();
        } catch (ClassNotFoundException | SQLException e) {
            out.println("<html><body><b>Error: " + e.getMessage() + "</b></body></html>");
        }
    }

}
