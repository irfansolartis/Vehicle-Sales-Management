package project;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;


/**
 * Servlet implementation class addUserServlet
 */
public class addUserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String url = "jdbc:mysql://localhost:3306/vehicle_sales_db";
        String userName = "root";
        String password = "password";

        String name = request.getParameter("name");
        String username = request.getParameter("username");
        String pass = request.getParameter("password");
        String role = request.getParameter("role");

        try {
            Connection conn = DriverManager.getConnection(url, userName, password);
            String query = "INSERT INTO users (name, user_name, password, role) VALUES (?, ?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, name);
            pstmt.setString(2, username);
            pstmt.setString(3, pass);
            pstmt.setString(4, role);
            int rowCount = pstmt.executeUpdate();

            if (rowCount > 0) {
                request.setAttribute("successMessage", "User added successfully!");
                request.getRequestDispatcher("add_user.jsp").include(request, response);
            } else {
            	request.setAttribute("failureMessage", "Failed to add user!");
                request.getRequestDispatcher("add_user.jsp").include(request, response);
            }

            pstmt.close();
            conn.close();
        } catch (SQLException e) {
            out.println("<script>alert('Error: " + e.getMessage() + "');</script>");
            request.getRequestDispatcher("add_user.jsp").include(request, response);
        }
    }

}
