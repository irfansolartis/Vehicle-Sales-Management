package project;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.util.ByteArrayDataSource;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.*;
import javax.mail.internet.*;

/**
 * Servlet implementation class generateBillServlet
 */
public class generateBillServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://localhost/vehicle_sales_db";
    static final String USER = "root";
    static final String PASS = "password";
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection conn = null;
		try {
			conn = DriverManager.getConnection(DB_URL, USER, PASS);
            Class.forName(JDBC_DRIVER);
            
            String seller = request.getParameter("seller");
			String buyer = "";
			String make = "";
			String model = "";
			String year = "";
			String engineNumber = "";
			String chassisNumber = "";
			String address = request.getParameter("address");
			int transactionId = Integer.parseInt(request.getParameter("transactionId"));
			String buyerEmail = request.getParameter("buyerEmail");
            
            String sql = "SELECT v.owner, v.make, v.model, v.year, v.engine_number, v.chassis_number " +
                    "FROM transaction t " +
                    "JOIN vehicle v ON t.vehicle_id = v.vehicle_id " +
                    "WHERE t.transaction_id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, transactionId);
            ResultSet rs = stmt.executeQuery();
	
            if (rs.next()) {
            	buyer = rs.getString("owner");
            	make = rs.getString("make");
            	model = rs.getString("model");
            	year = rs.getString("year");
            	engineNumber = rs.getString("engine_number");
            	chassisNumber = rs.getString("chassis_number");
            } else {
            	System.out.println("No owner found for transaction ID " + transactionId);
            }
            
			String vehicleDetails = getVehicleDetails(conn, transactionId);
			double pricePaid = getPricePaid(conn, transactionId);
			
            PDDocument document = new PDDocument();
            PDPage page = new PDPage();
            document.addPage(page);

            PDPageContentStream contentStream = new PDPageContentStream(document, page);

            addCenteredText(contentStream, "BILL OF SALE", PDType1Font.HELVETICA_BOLD, 14, page);

            float pageHeight = page.getMediaBox().getHeight();
            float lineHeight = 50; // Adjust as needed for spacing between lines

            float startY = pageHeight - 50; // Initial starting Y position

            startY -= lineHeight; // Adjust for the first line after the title
            addTextWithUnderline(contentStream, "" + LocalDate.now(), PDType1Font.HELVETICA, 12, 100, startY);
            startY -= lineHeight - 30;
            addText(contentStream, "DATE OF PURCHASE", PDType1Font.HELVETICA, 12, 100, startY);
            startY -= lineHeight;
            addText(contentStream, "I, (SELLER) ", PDType1Font.HELVETICA, 12, 100, startY);
            addTextWithUnderline(contentStream, "" + seller, PDType1Font.HELVETICA, 12, 100 + PDType1Font.HELVETICA.getStringWidth("I, (SELLER) ") / 1000 * 12, startY);
            addText(contentStream, " do hereby", PDType1Font.HELVETICA, 12, 100 + PDType1Font.HELVETICA.getStringWidth("I, (SELLER) " + seller) / 1000 * 12, startY);
            startY -= lineHeight;
            addText(contentStream, "grant, bargain, and convey all rights, title, and interest in and to the automobile", PDType1Font.HELVETICA, 12, 100, startY);
            startY -= lineHeight;
            addText(contentStream, "described as follows to:", PDType1Font.HELVETICA, 12, 100, startY);
            startY -= lineHeight;
            addText(contentStream, "(BUYER) ", PDType1Font.HELVETICA, 12, 100, startY);
            addTextWithUnderline(contentStream, "" + buyer, PDType1Font.HELVETICA, 12, 100 + PDType1Font.HELVETICA.getStringWidth("(BUYER) ") / 1000 * 12, startY);
            startY -= lineHeight;
            addText(contentStream, "(ADDRESS) ", PDType1Font.HELVETICA, 12, 100, startY);
            addTextWithUnderline(contentStream, "" + address, PDType1Font.HELVETICA, 12, 100 + PDType1Font.HELVETICA.getStringWidth("(ADDRESS) ") / 1000 * 12, startY);
            startY -= lineHeight;
            addText(contentStream, "PRICE PAID $", PDType1Font.HELVETICA, 12, 100, startY);
            addTextWithUnderline(contentStream, "" + pricePaid, PDType1Font.HELVETICA, 12, 100 + PDType1Font.HELVETICA.getStringWidth("PRICE PAID $") / 1000 * 12, startY);
            startY -= lineHeight;
            addTextWithUnderline(contentStream, "DESCRIPTION OF VEHICLE:", PDType1Font.HELVETICA, 12, 100, startY);
            startY -= lineHeight;
            addText(contentStream, "Engine Number: ", PDType1Font.HELVETICA, 12, 100, startY);
            addTextWithUnderline(contentStream, "" + engineNumber, PDType1Font.HELVETICA, 12, 100 + PDType1Font.HELVETICA.getStringWidth("Engine Number: ") / 1000 * 12, startY);
            startY -= lineHeight;
            addText(contentStream, "Chassis Number: ", PDType1Font.HELVETICA, 12, 100, startY);
            addTextWithUnderline(contentStream, "" + chassisNumber, PDType1Font.HELVETICA, 12, 100 + PDType1Font.HELVETICA.getStringWidth("Chassis Number: ") / 1000 * 12, startY);
            startY -= lineHeight;
            addText(contentStream, "Vehicle (Make, Model, Year): ", PDType1Font.HELVETICA, 12, 100, startY);
            addTextWithUnderline(contentStream, vehicleDetails, PDType1Font.HELVETICA, 12, 100 + PDType1Font.HELVETICA.getStringWidth("Vehicle (Make, Model, Year): ") / 1000 * 12, startY);

            // Close content stream
            contentStream.close();

            document.save(response.getOutputStream());

            
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            document.save(byteArrayOutputStream);
            byte[] pdfBytes = byteArrayOutputStream.toByteArray();
            ByteArrayInputStream pdfInputStream = new ByteArrayInputStream(pdfBytes);
            sendEmailWithAttachment(pdfInputStream, transactionId, buyerEmail);
            document.close();


        } catch (Exception e) {
            e.printStackTrace();
        }
	}
	public static void addText(PDPageContentStream contentStream, String text, PDType1Font font, float fontSize, float x, float y) throws IOException {
        contentStream.beginText();
        contentStream.setFont(font, fontSize);
        contentStream.newLineAtOffset(x, y);
        contentStream.showText(text);
        contentStream.endText();
    }
    
    public static void addCenteredText(PDPageContentStream contentStream, String text, PDType1Font font, float fontSize, PDPage page) throws IOException {
        contentStream.beginText();
        contentStream.setFont(font, fontSize);
        float textWidth = font.getStringWidth(text) / 1000 * fontSize;
        float startX = (page.getMediaBox().getWidth() - textWidth) / 2;
        float startY = page.getMediaBox().getHeight() - 50; // Adjust vertical position as needed
        contentStream.newLineAtOffset(startX, startY);
        contentStream.showText(text);
        contentStream.endText();
    }

    public static void addTextWithUnderline(PDPageContentStream contentStream, String text, PDType1Font font, float fontSize, float x, float y) throws IOException {
        contentStream.beginText();
        contentStream.setFont(font, fontSize);
        contentStream.newLineAtOffset(x, y);
        contentStream.showText(text);
        contentStream.endText();

        // Calculate the width of the text
        float textWidth = font.getStringWidth(text) / 1000 * fontSize;

        // Draw underline
        contentStream.moveTo(x, y - 1 * fontSize + 10); // Adjust the vertical position for underline
        contentStream.lineTo(x + textWidth, y - 1 * fontSize + 10); // Adjust the position for underline
        contentStream.stroke();
    }
    
    private static double getPricePaid(Connection conn, int transactionId) throws SQLException {
        double pricePaid = 0.0;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            String query = "SELECT amount FROM Transaction WHERE transaction_id = ?";
            pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, transactionId);
            rs = pstmt.executeQuery();
            if (rs.next()) {
                pricePaid = rs.getDouble("amount");
            }
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (pstmt != null) {
                pstmt.close();
            }
        }
        return pricePaid;
    }
    
    private static String getVehicleDetails(Connection conn, int transactionId) throws SQLException {
        String vehicleDetails = "";
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            String query = "SELECT make, model, year FROM Vehicle WHERE vehicle_id = (SELECT vehicle_id FROM Transaction WHERE transaction_id = ?)";
            pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, transactionId);
            rs = pstmt.executeQuery();
            if (rs.next()) {
                String make = rs.getString("make");
                String model = rs.getString("model");
                int year = rs.getInt("year");
                vehicleDetails = make + " " + model + " (" + year + ")";
            }
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (pstmt != null) {
                pstmt.close();
            }
        }
        return vehicleDetails;
    }
    
    private static void sendEmailWithAttachment(InputStream pdfInputStream, int transactionId, String recipientEmail) {
        final String username = "irfansolartissample@outlook.com"; // Your email
        final String password = "Sol@rtis1029"; // Your password
        String smtpHost = "smtp.office365.com"; // SMTP server host
        int smtpPort = 587; // SMTP server port

        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", smtpHost);
        props.put("mail.smtp.port", smtpPort);

        Session session = Session.getInstance(props, new Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(username, password);
            }
        });

        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(username));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipientEmail));
            message.setSubject("Bill of Sale");

            // Create MimeBodyPart for the PDF attachment
            MimeBodyPart attachmentPart = new MimeBodyPart();
            attachmentPart.setDisposition(MimeBodyPart.ATTACHMENT);
            attachmentPart.setFileName("BillOfSale" + transactionId + ".pdf");

            // Create DataSource from InputStream
            DataSource source = new ByteArrayDataSource(pdfInputStream, "application/pdf");
            attachmentPart.setDataHandler(new DataHandler(source));

            // Create Multipart and add attachment
            Multipart multipart = new MimeMultipart();
            multipart.addBodyPart(attachmentPart);

            // Set content of the message
            message.setContent(multipart);

            // Send the message
            Transport.send(message);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
