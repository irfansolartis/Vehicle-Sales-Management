package project;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * Servlet implementation class editVehicleServlet
 */
public class editVehicleServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://localhost/vehicle_sales_db";
    static final String USER = "root";
    static final String PASS = "password";
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String url = "jdbc:mysql://localhost:3306/vehicle_sales_db";
        String userName = "root";
        String password = "password";

        try {
            Connection conn = DriverManager.getConnection(url, userName, password);

            String vehicleId = request.getParameter("vehicleId");
            String make = request.getParameter("make");
            String model = request.getParameter("model");
            int year = Integer.parseInt(request.getParameter("year"));
            double price = Double.parseDouble(request.getParameter("price"));
            String owner = request.getParameter("owner");
            String engineNumber = request.getParameter("engineNumber");
            String chassisNumber = request.getParameter("chassisNumber");
            String coverageStatus = request.getParameter("insuranceCoverageStatus");

            String updateVehicleQuery = "UPDATE vehicle SET make=?, model=?, year=?, price=?, owner=?, engine_number=?, chassis_number=?, insurance_coverage_status=? WHERE vehicle_id=?";
            PreparedStatement pstmt = conn.prepareStatement(updateVehicleQuery);
            pstmt.setString(1, make);
            pstmt.setString(2, model);
            pstmt.setInt(3, year);
            pstmt.setDouble(4, price);
            pstmt.setString(5, owner);
            pstmt.setString(6, engineNumber);
            pstmt.setString(7, chassisNumber);
            pstmt.setString(8, coverageStatus);
            pstmt.setString(9, vehicleId);
            int updatedRows = pstmt.executeUpdate();
            pstmt.close();
            conn.close();

            if (updatedRows > 0) {
                request.setAttribute("successMessage", "Vehicle details updated successfully.");
                request.getRequestDispatcher("edit_vehicle.jsp").forward(request, response);
            } else {
            	request.setAttribute("failureMessage", "Failed to edit vehicle details!");
                request.getRequestDispatcher("edit_vehicle.jsp").forward(request, response);
            }
        } catch (SQLException e) {
            out.println("<html><body><b>Error: " + e.getMessage() + "</b></body></html>");
        }
    }
}
