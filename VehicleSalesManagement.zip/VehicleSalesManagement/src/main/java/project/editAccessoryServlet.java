package project;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * Servlet implementation class addAccessoryServlet
 */
public class editAccessoryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Retrieve parameters from the request
        int vehicleId = Integer.parseInt(request.getParameter("vehicleId"));
        String[] selectedAccessories = request.getParameterValues("accessory");

        // Concatenate selected accessories into a single string
        StringBuilder accessoriesStrBuilder = new StringBuilder();
        if (selectedAccessories != null && selectedAccessories.length > 0) {
            for (String accessory : selectedAccessories) {
                accessoriesStrBuilder.append(accessory).append(", ");
            }
            // Remove the trailing comma and space
            accessoriesStrBuilder.setLength(accessoriesStrBuilder.length() - 2);
        }
        String accessories = accessoriesStrBuilder.toString();

        // Database connection parameters
        String url = "jdbc:mysql://localhost:3306/vehicle_sales_db";
        String username = "root";
        String password = "password";

        // SQL query to insert the record into the accessories table
        String sql = "UPDATE accessories SET accessories=? WHERE vehicle_id=?";

        try (Connection conn = DriverManager.getConnection(url, username, password);
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            // Set parameters in the SQL query
            stmt.setString(1, accessories);
            stmt.setInt(2, vehicleId);

            // Execute the query
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
            	request.setAttribute("successMessage", "Accessories edited successfully!");
                request.getRequestDispatcher("add_accessory.jsp").include(request, response);
            } else {
            	request.setAttribute("failureMessage", "Failed to edit Accessories!");
                request.getRequestDispatcher("add_accessory.jsp").include(request, response);
            }
        } catch (SQLException e) {
            out.println("<h3>Error: " + e.getMessage() + "</h3>");
        }
    }

}
