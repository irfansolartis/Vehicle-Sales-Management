package project;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class calculateVehicleScoreServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    // Define weightage for each factor
    private static final double ENGINE_POWER_WEIGHT = 0.2;
    private static final double TOTAL_MILEAGE_WEIGHT = 0.15;
    private static final double SAFETY_RATING_WEIGHT = 0.15;
    private static final double VEHICLE_CONDITION_WEIGHT = 0.1;
    private static final double YEAR_WEIGHT = 0.2;
    private static final double PRICE_WEIGHT = 0.2;
    
    // Threshold for insurance eligibility
    private static final double INSURANCE_THRESHOLD = 90.0;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Retrieve parameters from the request
        int vehicleId = Integer.parseInt(request.getParameter("vehicleId"));
        int enginePower = Integer.parseInt(request.getParameter("enginePower"));
        int totalMileage = Integer.parseInt(request.getParameter("totalMileage"));
        int safetyRating = Integer.parseInt(request.getParameter("safetyRating"));
        int vehicleCondition = Integer.parseInt(request.getParameter("vehicleCondition"));
        
        // Initialize variables to store year and price
        int year = 0;
        double price = 0.0;

        // Database connection parameters
        String url = "jdbc:mysql://localhost:3306/vehicle_sales_db";
        String username = "root";
        String password = "password";

        // SQL query to retrieve year and price based on vehicle ID
        String sql = "SELECT year, price FROM vehicle WHERE vehicle_id = ?";

        try (Connection conn = DriverManager.getConnection(url, username, password);
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            // Set the vehicle ID parameter in the SQL query
            stmt.setInt(1, vehicleId);

            // Execute the query
            ResultSet rs = stmt.executeQuery();

            // If a matching record is found, retrieve year and price
            if (rs.next()) {
                year = rs.getInt("year");
                price = rs.getDouble("price");
            }
        } catch (SQLException e) {
            out.println("Error: " + e.getMessage());
            return;
        }

        

        // Calculate score based on weighted sum
        double score = calculateVehicleScore(enginePower, totalMileage, safetyRating, vehicleCondition, year, price) * 100;
        
        String insuranceCoverageStatus = "";

        // Check insurance eligibility
        if (score > INSURANCE_THRESHOLD) {
        	insuranceCoverageStatus = "Yes";
        } else {
        	insuranceCoverageStatus = "No";
        }
      

        // Insert score data if not exist into the score table
        String insertScoreQuery = "INSERT IGNORE INTO score (vehicle_score, insurance_coverage_status, vehicle_id) VALUES (?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(url, username, password);
            PreparedStatement stmt = conn.prepareStatement(insertScoreQuery)) {
            stmt.setDouble(1, score);
            stmt.setString(2, insuranceCoverageStatus);
            stmt.setInt(3, vehicleId);
            
            // Execute the update
            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
            	String updateInsuranceCoverageQuery = "UPDATE vehicle SET insurance_coverage_status = ? WHERE vehicle_id = ?";
            	PreparedStatement pstmt = conn.prepareStatement(updateInsuranceCoverageQuery);
            	pstmt.setString(1, insuranceCoverageStatus);
            	pstmt.setInt(2, vehicleId);

            	// Execute the update
            	pstmt.executeUpdate();
            	
                // Pass the calculated score and other details to display_vehicle_score.jsp
                request.setAttribute("vehicleId", vehicleId);
                request.setAttribute("score", score);
                request.getRequestDispatcher("display_vehicle_score.jsp").forward(request, response);
            } else {
                out.println("Failed to insert score data.");
            }
        } catch (SQLException e) {
            out.println("Error: " + e.getMessage());
        }
    }
    
    // Method to calculate the vehicle score
    private static double calculateVehicleScore(int enginePower, int totalMileage, int safetyRating, double vehicleCondition, int year, double price) {
        // Normalize values if necessary (optional)
        
        // Calculate weighted sum of factors
        double weightedSum = (ENGINE_POWER_WEIGHT * normalizeEnginePower(enginePower)) +
                             (TOTAL_MILEAGE_WEIGHT * normalizeTotalMileage(totalMileage)) +
                             (SAFETY_RATING_WEIGHT * safetyRating) +
                             (VEHICLE_CONDITION_WEIGHT * vehicleCondition) +
                             (YEAR_WEIGHT * normalizeYear(year)) +
                             (PRICE_WEIGHT * normalizePrice(price));
        
        return weightedSum;
    }
    
    // Normalize engine power value (for example purposes only)
    private static double normalizeEnginePower(int enginePower) {
        // Assuming engine power ranges from 0 to 500 horsepower
        return (double)enginePower / 1000.0;
    }
    
    // Normalize total mileage value (for example purposes only)
    private static double normalizeTotalMileage(int totalMileage) {
        // Assuming total mileage ranges from 0 to 100,000 miles
        return (double)totalMileage / 1000000.0;
    }
    
    // Normalize year value (for example purposes only)
    private static double normalizeYear(int year) {
        // Assuming year ranges from 2000 to 2025
        return 1.0 - ((double)(year - 2000) / 25.0);
    }
    
    // Normalize price value (for example purposes only)
    private static double normalizePrice(double price) {
        // Assuming price ranges from 0 to 100,000 dollars
        return price / 1000000.0;
    }
}
