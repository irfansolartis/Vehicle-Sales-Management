package project;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.io.PrintWriter;


/**
 * Servlet implementation class addVehicleServlet
 */
public class addVehicleServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://localhost/vehicle_sales_db";
    static final String USER = "root";
    static final String PASS = "password";

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Database connection parameters
        String url = "jdbc:mysql://localhost:3306/vehicle_sales_db";
        String username = "root";
        String password = "password";

        // Get form data
        String make = request.getParameter("make");
        String model = request.getParameter("model");
        int year = Integer.parseInt(request.getParameter("year"));
        double price = Double.parseDouble(request.getParameter("price"));
        String owner = request.getParameter("owner");
        String engineNumber = request.getParameter("engineNumber");
        String chassisNumber = request.getParameter("chassisNumber");

        // SQL query to insert vehicle details into the database
        String insertQuery = "INSERT INTO vehicle (make, model, year, price, owner, engine_number, chassis_number, insurance_coverage_status) VALUES (?, ?, ?, ?, ?, ?, ?, 'N/A')";

        try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Connect to the database
            Connection conn = DriverManager.getConnection(url, username, password);

            // Create a PreparedStatement with the insert query
            PreparedStatement pstmt = conn.prepareStatement(insertQuery);

            // Set parameters for the PreparedStatement
            pstmt.setString(1, make);
            pstmt.setString(2, model);
            pstmt.setInt(3, year);
            pstmt.setDouble(4, price);
            pstmt.setString(5, owner);
            pstmt.setString(6, engineNumber);
            pstmt.setString(7, chassisNumber);

            // Execute the insert query
            int rowsAffected = pstmt.executeUpdate();

            // Close the PreparedStatement and database connection
            pstmt.close();
            conn.close();

            // Check if the vehicle was added successfully
            if (rowsAffected > 0) {
            	request.setAttribute("successMessage", "Vehicle added successfully!");
                request.getRequestDispatcher("add_vehicle.jsp").include(request, response);
            } else {
            	request.setAttribute("failureMessage", "Failed to add vehicle!");
                request.getRequestDispatcher("add_user.jsp").include(request, response);
            }
        } catch (ClassNotFoundException | SQLException e) {
            // Handle any errors that occur during JDBC operations
            e.printStackTrace();
            out.println("<h3>Error: " + e.getMessage() + "</h3>");
        }
    }
}