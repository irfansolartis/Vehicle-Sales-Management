package project;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Servlet implementation class editTransactionServlet
 */
public class editTransactionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://localhost/vehicle_sales_db";
    static final String USER = "root";
    static final String PASS = "password";
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String url = "jdbc:mysql://localhost:3306/vehicle_sales_db";
        String userName = "root";
        String password = "password";

        try {
            Connection conn = DriverManager.getConnection(url, userName, password);

            double amount = Double.parseDouble(request.getParameter("transactionAmount"));
            String transactionDate = request.getParameter("transactionDate");
            int vehicleId = Integer.parseInt(request.getParameter("vehicleId"));

            // Calculate profit for the corresponding vehicle
            double purchasePrice = getPurchasePriceForVehicle(conn, vehicleId);
            double profit = amount - purchasePrice;

            String updateTransactionQuery = "UPDATE transaction SET amount=?, transaction_date=?, profit=? WHERE vehicle_id=?";
            PreparedStatement pstmt = conn.prepareStatement(updateTransactionQuery);
            pstmt.setDouble(1, amount);
            pstmt.setDate(2, Date.valueOf(transactionDate));
            pstmt.setDouble(3, profit);
            pstmt.setInt(4, vehicleId);
            int updatedRows = pstmt.executeUpdate();
            pstmt.close();
            conn.close();

            if (updatedRows > 0) {
                request.setAttribute("successMessage", "Transaction details updated successfully!");
                request.getRequestDispatcher("edit_transaction.jsp").forward(request, response);
            } else {
            	request.setAttribute("failureMessage", "Failed to edit transaction details!");
                request.getRequestDispatcher("edit_transaction.jsp").forward(request, response);
            }
        } catch (SQLException e) {
            out.println("<html><body><b>Error: " + e.getMessage() + "</b></body></html>");
        }
    }
    
    private static double getPurchasePriceForVehicle(Connection conn, int vehicleId) throws SQLException {
        double purchasePrice = 0.0;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            String query = "SELECT price FROM Vehicle WHERE vehicle_id = ?";
            pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, vehicleId);
            rs = pstmt.executeQuery();
            if (rs.next()) {
                purchasePrice = rs.getDouble("price");
            }
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (pstmt != null) {
                pstmt.close();
            }
        }
        return purchasePrice;
    }
}
