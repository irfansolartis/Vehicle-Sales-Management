package project;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class addTransactionServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://localhost/vehicle_sales_db";
    static final String USER = "root";
    static final String PASS = "password";

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Connection conn = null;
        PreparedStatement insertTransactionStmt = null;

        try {
        	conn = DriverManager.getConnection(DB_URL, USER, PASS);
            Class.forName(JDBC_DRIVER);

            double amount = Double.parseDouble(request.getParameter("transactionAmount"));
            String transactionDate = request.getParameter("transactionDate");
            int vehicleId = Integer.parseInt(request.getParameter("vehicleId"));

            // Calculate profit for the corresponding vehicle
            double purchasePrice = getPurchasePriceForVehicle(conn, vehicleId);
            double profit = amount - purchasePrice;

            // Store transaction details including profit in the database
            String insertTransactionQuery = "INSERT INTO Transaction (amount, transaction_date, profit, vehicle_id) VALUES (?, ?, ?, ?)";
            insertTransactionStmt = conn.prepareStatement(insertTransactionQuery);
            insertTransactionStmt.setDouble(1, amount);
            insertTransactionStmt.setDate(2, Date.valueOf(transactionDate));
            insertTransactionStmt.setDouble(3, profit);
            insertTransactionStmt.setInt(4, vehicleId);
            insertTransactionStmt.executeUpdate();

            // Set success message attribute and redirect to add_vehicle.jsp
            request.setAttribute("successMessage", "Transaction added successfully!");
            request.getRequestDispatcher("add_transaction.jsp").forward(request, response);
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle exception here, for example, redirecting to an error page
        } catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
            // Close resources in finally block
            try {
                if (insertTransactionStmt != null) {
                    insertTransactionStmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    private static double getPurchasePriceForVehicle(Connection conn, int vehicleId) throws SQLException {
        double purchasePrice = 0.0;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            String query = "SELECT price FROM Vehicle WHERE vehicle_id = ?";
            pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, vehicleId);
            rs = pstmt.executeQuery();
            if (rs.next()) {
                purchasePrice = rs.getDouble("price");
            }
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (pstmt != null) {
                pstmt.close();
            }
        }
        return purchasePrice;
    }
}
