package project;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;
import java.sql.DriverManager;

public class displayTransactionServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://localhost/vehicle_sales_db";
    static final String USER = "root";
    static final String PASS = "password";

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
        	conn = DriverManager.getConnection(DB_URL, USER, PASS);
            Class.forName(JDBC_DRIVER);
            
            
            // Execute SQL query to retrieve all records from the transaction table
            String selectQuery = "SELECT * FROM transaction";
            pstmt = conn.prepareStatement(selectQuery);
            rs = pstmt.executeQuery();
            
            // Iterate through the result set and update the profits
            while (rs.next()) {
                int transactionId = rs.getInt("transaction_id");
                double amount = rs.getDouble("amount");
                int vehicleId = rs.getInt("vehicle_id");

                // Retrieve the price of the vehicle associated with this transaction
                String getPriceQuery = "SELECT price FROM vehicle WHERE vehicle_id=?";
                PreparedStatement getPriceStmt = conn.prepareStatement(getPriceQuery);
                getPriceStmt.setInt(1, vehicleId);
                ResultSet priceRs = getPriceStmt.executeQuery();

                if (priceRs.next()) {
                	
                	long differenceInDays = 0;
                    String query = "SELECT DISTINCT vehicle_id FROM Transaction";
                    pstmt = conn.prepareStatement(query);
                    rs = pstmt.executeQuery();
                    while (rs.next()) {
                    	int vehicleIdForPeriod  = rs.getInt("vehicle_id");
                        Date dateOfPurchase = getDateOfPurchase(conn, vehicleIdForPeriod);
                        // Calculate the number of days between start and end dates
                    	Date currentDate = new Date(System.currentTimeMillis());
                        long differenceInMilliseconds = currentDate.getTime() - dateOfPurchase.getTime();
                        differenceInDays = differenceInMilliseconds / (1000 * 60 * 60 * 24);
                    }
                    
                    if (differenceInDays > 20) {
	                    double price = priceRs.getDouble("price");
	                    double profit = amount - price;
	
	                    // Update the profit in the transaction table
	                    String updateQuery = "UPDATE transaction SET profit=? WHERE transaction_id=?";
	                    PreparedStatement updateStmt = conn.prepareStatement(updateQuery);
	                    updateStmt.setDouble(1, profit);
	                    updateStmt.setInt(2, transactionId);
	                    updateStmt.executeUpdate();
	                    updateStmt.close();
	                
                    }
                }
                getPriceStmt.close();
                priceRs.close();
            }
            
            
            String query = "SELECT DISTINCT vehicle_id FROM Transaction";
            pstmt = conn.prepareStatement(query);
            rs = pstmt.executeQuery();
            while (rs.next()) {
                int vehicleIdForPeriod  = rs.getInt("vehicle_id");
                Date dateOfPurchase = getDateOfPurchase(conn, vehicleIdForPeriod);
                if (dateOfPurchase != null) {
                    Date currentDate = new Date(System.currentTimeMillis());
                    double totalProfitForPeriod = calculateProfitForPeriod(conn, dateOfPurchase, currentDate, vehicleIdForPeriod);
                } else {
                    System.out.println("No purchase date found for vehicle ID " + vehicleIdForPeriod );
                }
            }

            // Forward the request to display_transaction.jsp
            request.getRequestDispatcher("display_transaction.jsp").forward(request, response);
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle database errors, for example, redirect to an error page
        } catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
            // Close resources in finally block
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pstmt != null) {
                    pstmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    private static double calculateProfitForPeriod(Connection conn, Date startDate, Date endDate, int vehicleId) throws SQLException {
        double totalProfit = 0.0;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
        	String query = "SELECT SUM(profit) AS total_profit FROM Transaction WHERE transaction_date BETWEEN ? AND ? AND vehicle_id = ?";
            pstmt = conn.prepareStatement(query);
            pstmt.setDate(1, startDate);
            pstmt.setDate(2, endDate);
            pstmt.setInt(3, vehicleId);
            rs = pstmt.executeQuery();
            if (rs.next()) {
                totalProfit = rs.getDouble("total_profit");
            }

            // Calculate the number of days between start and end dates
            long differenceInMilliseconds = endDate.getTime() - startDate.getTime();
            long differenceInDays = differenceInMilliseconds / (1000 * 60 * 60 * 24);

            // If the difference is greater than 20 days, calculate penalty and interest
            if (differenceInDays > 20) {
                double penalty = 500.0; // Example penalty amount
                double interestRate = 0.05; // Example interest rate (5%)
                double interest = totalProfit * interestRate;

                // Add penalty and interest to the total profit
                totalProfit += penalty;
                totalProfit += interest;

                // Update the profit in the Transaction table
                String updateQuery = "UPDATE Transaction SET transaction_date = ?, profit = ? WHERE vehicle_id = ?";
                pstmt = conn.prepareStatement(updateQuery);
                pstmt.setDate(1, endDate);
                pstmt.setDouble(2, totalProfit);
                pstmt.setInt(3, vehicleId);
                pstmt.executeUpdate();
            }
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (pstmt != null) {
                pstmt.close();
            }
        }
        return totalProfit;
    }
    
    private static Date getDateOfPurchase(Connection conn, int vehicleId) throws SQLException {
        Date dateOfPurchase = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            String query = "SELECT transaction_date FROM Transaction WHERE vehicle_id = ? ORDER BY transaction_date ASC LIMIT 1";
            pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, vehicleId);
            rs = pstmt.executeQuery();
            if (rs.next()) {
                dateOfPurchase = rs.getDate("transaction_date");
            }
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (pstmt != null) {
                pstmt.close();
            }
        }
        return dateOfPurchase;
    }
}
