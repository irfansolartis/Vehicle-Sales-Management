package project;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * Servlet implementation class removeUserServlet
 */
public class removeAccessoryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String url = "jdbc:mysql://localhost:3306/vehicle_sales_db";
        String userName = "root";
        String password = "password";

        try {
            Connection conn = DriverManager.getConnection(url, userName, password);

            String vehicleId = request.getParameter("vehicleId");

            String deleteUserQuery = "DELETE FROM accessories WHERE vehicle_id=?";
            PreparedStatement pstmt = conn.prepareStatement(deleteUserQuery);
            pstmt.setString(1, vehicleId);

            int rowsDeleted = pstmt.executeUpdate();
            if (rowsDeleted > 0) {
                request.setAttribute("successMessage", "Accessories removed successfully!");
                request.getRequestDispatcher("remove_accessory.jsp").forward(request, response);
            } else {
                request.setAttribute("failureMessage", "Failed to remove accessories!");
                request.getRequestDispatcher("remove_accessory.jsp").forward(request, response);
            }

            pstmt.close();
            conn.close();
        } catch (SQLException e) {
            out.println("<html><body><b>Error: " + e.getMessage() + "</b></body></html>");
        }

    }

}
